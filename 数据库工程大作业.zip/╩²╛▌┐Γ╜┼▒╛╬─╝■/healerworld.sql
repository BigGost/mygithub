/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 8.0.21 : Database - healerworld
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`healerworld` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `healerworld`;

/*Table structure for table `appointment` */

DROP TABLE IF EXISTS `appointment`;

CREATE TABLE `appointment` (
  `aid` bigint NOT NULL,
  `uid` bigint NOT NULL,
  `visitTime` varchar(100) DEFAULT NULL,
  `did` bigint NOT NULL,
  `name` varchar(64) NOT NULL,
  `idcast` varchar(20) DEFAULT NULL,
  `aphone` varchar(20) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`,`did`),
  UNIQUE KEY `aid` (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `appointment` */

insert  into `appointment`(`aid`,`uid`,`visitTime`,`did`,`name`,`idcast`,`aphone`,`createtime`,`updatetime`) values (160785337493176,160785319837470,'2020年-12月-15日(星期二)上午',1,'test','123456789','12345678901','2020-12-13 09:56:15','2020-12-13 09:56:15'),(160838297737499,160785406611201,'2020年-12月-24日(星期四)上午',6,'test1','123456','123456','2020-12-19 13:02:57','2020-12-19 13:02:57'),(160830466476325,160830461217664,'2020年-12月-24日(星期四)上午',1,'dlw0527','dlw0527','dlw0527','2020-12-18 15:17:45','2020-12-18 15:17:45');

/*Table structure for table `dept` */

DROP TABLE IF EXISTS `dept`;

CREATE TABLE `dept` (
  `deid` bigint NOT NULL,
  `degrade` int DEFAULT NULL COMMENT '1 一级科室 2 二级科室',
  `dename` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`deid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `dept` */

insert  into `dept`(`deid`,`degrade`,`dename`) values (1,1,'内科'),(2,1,'儿科'),(3,1,'眼科'),(4,1,'骨科'),(5,1,'口腔科'),(6,2,'心血管内科'),(7,2,'神经内科'),(8,2,'内分泌科'),(9,2,'血液科'),(10,2,'肝病科');

/*Table structure for table `doctor` */

DROP TABLE IF EXISTS `doctor`;

CREATE TABLE `doctor` (
  `did` bigint NOT NULL,
  `dname` varchar(64) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `hid` bigint DEFAULT NULL,
  `score` float DEFAULT NULL,
  `grade` int DEFAULT NULL COMMENT '1主任医师 2副主任医师 3主治医师 4普通医师',
  `deid` bigint DEFAULT NULL,
  `skill` varchar(100) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `image` varchar(64) DEFAULT NULL COMMENT '图片地址',
  `surgeryWeek` varchar(200) DEFAULT NULL COMMENT '手术日期',
  PRIMARY KEY (`did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `doctor` */

insert  into `doctor`(`did`,`dname`,`gender`,`hid`,`score`,`grade`,`deid`,`skill`,`description`,`image`,`surgeryWeek`) values (1,'曹云','男',1,9.8,2,1,'治疗口腔','从1995到至今武汉同济医院;华中科技大学同济医学院外科学博士；美国加州大学洛杉矶分校（UCLA医学中心泌尿外科博士后','images/yisheng1.png','星期二上午,星期二下午,星期四上午,星期五晚上'),(2,'张三','男',2,9.8,1,1,'治疗口腔','GOOD','images/yisheng1.png','星期一下午,星期三上午,星期三下午'),(3,'李四','男',3,9.8,1,1,'治疗口腔','GOOD','images/yisheng1.png','星期二上午,星期二下午,星期四上午,星期五晚上'),(4,'李五','女',5,9.7,3,2,NULL,'GOOD','images/yisheng2.png','星期一下午,星期三上午,星期三下午'),(5,'李六','男',5,9.6,4,2,NULL,'GOOD','images/yisheng1.png','星期三上午,星期三下午,星期五上午'),(6,'李七','女',8,9,2,1,NULL,'GOOD','images/yisheng2.png','星期三下午,星期四上午,星期四下午');

/*Table structure for table `hospital` */

DROP TABLE IF EXISTS `hospital`;

CREATE TABLE `hospital` (
  `hid` bigint NOT NULL,
  `hname` varchar(64) DEFAULT NULL,
  `hphone` varchar(64) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `score` float DEFAULT NULL,
  `grade` varchar(11) DEFAULT NULL COMMENT '1三甲医院 2三乙医院 3二甲医院 4二级医院',
  `description` varchar(200) DEFAULT NULL,
  `insurance` int DEFAULT NULL COMMENT '医保',
  `image` varchar(64) DEFAULT NULL COMMENT '图片地址',
  `times` int DEFAULT NULL COMMENT '提供服务次数',
  PRIMARY KEY (`hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `hospital` */

insert  into `hospital`(`hid`,`hname`,`hphone`,`address`,`score`,`grade`,`description`,`insurance`,`image`,`times`) values (1,'武汉协和医院','123-123','武汉市武昌区',9.8,'三甲','good',1,'images/09fa513d269759eeaac0c0eeb5fb43166d22df07.jpg',2),(2,'广州协和医院','123-123','广州市白云区',9.8,'三乙','good',1,'images/09fa513d269759eeaac0c0eeb5fb43166d22df07.jpg',0),(3,'北京协和医院','123-123','北京市朝阳区',9.8,'二甲','good',0,'images/09fa513d269759eeaac0c0eeb5fb43166d22df07.jpg',0),(5,'上海协和医院','123-123','上海市xx区',9.8,'二级','good',0,'images/09fa513d269759eeaac0c0eeb5fb43166d22df07.jpg',0),(6,'深圳协和医院','123-123','深圳xx',9.8,'二甲','good',1,'images/09fa513d269759eeaac0c0eeb5fb43166d22df07.jpg',0),(8,'湛江协和医院','123-123','湛江市xx区',9.8,'二级','good',0,'images/09fa513d269759eeaac0c0eeb5fb43166d22df07.jpg',1);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `uid` bigint NOT NULL,
  `user` varchar(64) DEFAULT NULL,
  `pwd` varchar(64) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `phone` char(11) DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `code` varchar(64) DEFAULT NULL,
  `state` int DEFAULT '0',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`uid`,`user`,`pwd`,`name`,`gender`,`email`,`phone`,`createTime`,`updateTime`,`code`,`state`) values (160785319837470,'test','1544962681d702dab4aefdf580ce1d16','test','男','1093808591@qq.com','12345678901','2020-12-13 09:53:18','2020-12-13 09:53:18','d4e1847f8f2847afad944ae3ffa0eae2',NULL),(160785406611201,'test1','1544962681d702dab4aefdf580ce1d16','test1','男','123456@123.com','123','2020-12-13 10:07:46','2020-12-13 10:07:46','d3cce5a898674bb8a7eaa6df9dd4dba4',NULL),(160801391369012,'dlw1','e1439552bb33f597c283d054c7ff9c34','dlw1','女','123456@123.com','1234','2020-12-15 06:31:54','2020-12-15 06:31:54','e33a5ce13e9f4f56bdb0586f669fbcf8',NULL),(160801490112281,'test11','1544962681d702dab4aefdf580ce1d16','d3232','男','123456@123.com','123','2020-12-15 06:48:21','2020-12-15 06:48:21','0700ad36e5fe4365a054e75cb389731d',NULL),(160803588156668,'18834918240','527530994a87c05c996d9ee7b99d617c','张先生','男','751935284@qq.com','18834918240','2020-12-15 12:38:02','2020-12-15 12:38:02','3771367162964ac6aebf62721e42cdc2',NULL),(160803804093808,'test2','1544962681d702dab4aefdf580ce1d16','test2','男','123456@123.com','123456','2020-12-15 13:14:01','2020-12-15 13:14:01','13a746d1d5ae4157bc831e5b66f64e0f',NULL),(160830461217664,'dlw0527','1544962681d702dab4aefdf580ce1d16','dlw0527','男','123456@123.com','123','2020-12-18 15:16:52','2020-12-18 15:16:52','a8e1fbec06894735aa3d2ec59908c4ac',NULL),(160838084008500,'test12','1544962681d702dab4aefdf580ce1d16','test12','男','123456@123.com','123456789','2020-12-19 12:27:20','2020-12-19 12:27:20','bdf8cd004e2f4224aabf6bd87018ce12',NULL),(160838364043514,'zhanghao','1544962681d702dab4aefdf580ce1d16','张浩','男','1125868410@qq.com','16624709579','2020-12-19 13:14:00','2020-12-19 13:14:00','b4618129990c4871aa2201af4719c7fc',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
