package ManagementCon;

public class MajBean {
    private String Mno;
    private String Mname;
    private String Dno;
    private String Mhead;
    private String Mphone;
    
    public String getMno() {
        return Mno;
    }

    public String getMname() {
        return Mname;
    }
    public String getDno() {
        return Dno;
    }
    public String getMhead() {
        return Mhead;
    }

    public String getMphone() {
        return Mphone;
    }
 
    public void setMno(String Mno) {
        this.Mno = Mno;
    }
    public void setMname(String Mname) {
        this.Mname = Mname;
    }
    public void setDno(String Dno) {
        this.Dno = Dno;
    }
    public void setMhead(String Mhead) {
        this.Mhead = Mhead;
    }
    public void setMphone(String Mphone) {
        this.Mphone = Mphone;
    }


}
