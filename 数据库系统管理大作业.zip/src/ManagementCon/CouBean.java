package ManagementCon;

public class CouBean {
    private String Cno;
    private String Cname;
    private String Tname;
    private String Ctime;
    private String Ctype;

    public String getCno() {
        return Cno;
    }

    public String getCname() {
        return Cname;
    }
    
    public String getTname() {
        return Tname;
    }

    public String getCtime() {
        return Ctime;
    }

    public String getCtype() {
        return Ctype;
    }

    public void setCno(String Cno) {
        this.Cno = Cno;
    }
    public void setCname(String Cname) {
        this.Cname = Cname;
    }
    public void setTname(String Tname) {
        this.Tname = Tname;
    }
    public void setCtime(String ctime) {
        Ctime = ctime;
    }
    public void setCtype(String ctype) {
        Ctype = ctype;
    }
}

