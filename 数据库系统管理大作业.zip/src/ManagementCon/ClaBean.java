package ManagementCon;

public class ClaBean {
    private String Clno;
    private String Clname;
    private String Mname;
    private String Dname;
    private String Clhead;
    private String Clphone;
    
    public String getClno() {
        return Clno;
    }

    public String getClname() {
        return Clname;
    }
    public String getMname() {
        return Mname;
    }
    public String getDname() {
        return Dname;
    }
    public String getClhead() {
        return Clhead;
    }

    public String getClphone() {
        return Clphone;
    }
 
    public void setClno(String Clno) {
        this.Clno = Clno;
    }
    public void setClname(String Clname) {
        this.Clname = Clname;
    }
    public void setMname(String Mname) {
        this.Mname = Mname;
    }
    public void setDname(String Dname) {
        this.Dname = Dname;
    }
    public void setClhead(String Clhead) {
        this.Clhead = Clhead;
    }
    public void setClphone(String Clphone) {
        this.Clphone = Clphone;
    }
}