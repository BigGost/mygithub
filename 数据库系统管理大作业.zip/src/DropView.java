import java.sql.*;

public class DropView {
    public static void main(String args[]) throws SQLException, ClassNotFoundException {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://127.0.0.1:1433;databaseName=grade;user=test;password=123456";
        Connection con = DriverManager.getConnection(url);

        String SQL = "DROP VIEW CourseScoreAll";

        PreparedStatement psmt = con.prepareStatement(SQL);
        psmt.execute();

        con.close();
    }

}