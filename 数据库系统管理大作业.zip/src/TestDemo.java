import java.sql.*;

public class TestDemo {
    public static void main(String args[]) throws SQLException, ClassNotFoundException {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://127.0.0.1:1433;databaseName=Infor;user=TEST;password=123456";
        Connection con = DriverManager.getConnection(url);

//        String SQL = "select dbo.SumRes('2020001') as result";
        String SQL = "select * from Student where Clno='" + 02 + "' UNION select * from Student where Sname like '" +"��"+"%'";


        Statement stmt1 = con.createStatement();
        ResultSet rs1 = stmt1.executeQuery(SQL);


        while(rs1.next()){
            System.out.println(rs1.getString(1));
        }

        rs1.close();
        con.close();
    }

}
