import java.sql.*;

public class CreateView {
    public static void main(String args[]) throws SQLException, ClassNotFoundException {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://127.0.0.1:1433;databaseName=grade;user=test;password=123456";
        Connection con = DriverManager.getConnection(url);

        String SQL1 = "CREATE VIEW CoSELECT studentname, coursename, scores FROM student, course, score WHERE student.studentID=score.studentID and course.courseID=score.courseID)";

//        Statement stmt = con.createStatement();
//        ResultSet rs = stmt.executeQuery(SQL);

//        while (rs.next()) {
//            System.out.println(rs.getString(1) + " " + rs.getString(2)+ " " + rs.getString(3)+ " " + rs.getString(4)+ " " + rs.getString(5)+ " " + rs.getString(6));
//        }

        PreparedStatement psmt1 = con.prepareStatement(SQL1);
        psmt1.execute();


//        rs.close();
        con.close();
    }

}