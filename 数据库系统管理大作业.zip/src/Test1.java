import java.sql.*;

public class Test1 {
    public static void main(String args[]) throws SQLException, ClassNotFoundException {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://127.0.0.1:1433;databaseName=Information;user=test;password=123456";
        Connection con = DriverManager.getConnection(url);

//        String SQL = "SELECT  * FROM student";

        String ViewSQL1 = "SELECT  * FROM student_score";
        Statement ViewStmt = con.createStatement();
        ResultSet Vrs = ViewStmt.executeQuery(ViewSQL1);
        while(Vrs.next()){
            System.out.println(Vrs.getString(1)+ " " + Vrs.getString(2)+ " " + Vrs.getString(3) + " " + Vrs.getString(4));
        }

//        Statement stmt = con.createStatement();
//        ResultSet rs = stmt.executeQuery(SQL);


//        while (rs.next()) {
//            System.out.println(rs.getString(1) + " " + rs.getString(2)+ " " + rs.getString(3)+ " " + rs.getString(4)+ " " + rs.getString(5)+ " " + rs.getString(6));
//        }


//        rs.close();
        Vrs.close();
        con.close();
    }

}