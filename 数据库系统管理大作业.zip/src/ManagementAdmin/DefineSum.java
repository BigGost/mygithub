package ManagementAdmin;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import ManagementCon.ConAdmDB;
import ManagementStu.StuBean;

import java.awt.BorderLayout;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DefineSum extends JFrame implements ActionListener{
    private JLabel JLSno = new JLabel("������Ҫ��ѯ��ѧ�ţ�");
    private JTextField JTSno = new JTextField();
    private JButton JBSubmit = new JButton("ȷ��");
    private JButton JBCancel = new JButton("ȡ��");

    private JTextArea JT = new JTextArea();

    public DefineSum() {
        this.setTitle("��ѯѧ�����п�Ŀ�ɼ��ܺ�");
        getContentPane().setLayout(null);

        JLSno.setBounds(19,28,200,20);
        getContentPane().add(JLSno);
        JTSno.setBounds(19,58,119,29);
        getContentPane().add(JTSno);
        JBSubmit.setBounds(19,90,60,20);
        JBSubmit.addActionListener(this);
        getContentPane().add(JBSubmit);
        JBCancel.setBounds(80,90,60,20);
        JBCancel.addActionListener(this);
        getContentPane().add(JBCancel);
        this.setBounds(10, 10, 300, 200);
        this.setLocationRelativeTo(null);//��������Ļ�м���ʾ
        this.setVisible(true);
        JT.setBounds(200,60,50,50);
        getContentPane().add(JT);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==JBCancel){
            dispose();
        }

        if (e.getSource()==JBSubmit){
            AdminDAO dao = new AdminDAO();
            StuBean bean = new StuBean();
            bean.setSno(JTSno.getText());
            ArrayList list = dao.searchSCSum(bean);
//            System.out.println(list.toString());
            if (list.size() == 0) {
                JOptionPane.showMessageDialog(this, "û�����ѧ������Ϣ", "alert",
                        JOptionPane.INFORMATION_MESSAGE);
            }
            else {
                JT.setText(list.toString());
            }
        }
    }
}
