package ManagementAdmin;

import ManagementCon.CouBean;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GroupBy_Having extends JFrame implements ActionListener {
    private JButton JBSubmit = new JButton("����ƽ���ɼ������ѧ��ѧ��");
    private JButton JBCancel = new JButton("�˳�");
    private JTextArea JT= new JTextArea();

    public GroupBy_Having(){
        this.setTitle("��ѯĳ�γ̲������ѧ��");
        getContentPane().setLayout(null);
        JBSubmit.setBounds(10,107,200,20);
        getContentPane().add(JBSubmit);
        JBSubmit.addActionListener(this);
        JBCancel.setBounds(10,150,60,20);
        getContentPane().add(JBCancel);
        JBCancel.addActionListener(this);
        this.setBounds(10,10,736,400);
        this.setLocationRelativeTo(null);//��������Ļ�м���ʾ
        this.setVisible(true);
        JT.setBounds(220,10,450,320);
        JT.setLineWrap(true);//�Զ�����
        getContentPane().add(JT);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==JBCancel) {
            dispose();
        }
        if (e.getSource()==JBSubmit) {
            AdminDAO dao = new AdminDAO();
            ArrayList list = dao.searchPassStu();
            if (list.size() == 0) {
                JOptionPane.showMessageDialog(this, "û�����ѧ������Ϣ", "alert",
                        JOptionPane.INFORMATION_MESSAGE);
            }
            else {
                JT.setText("    ѧ��   |ƽ����"+"\n"+list.toString());
            }
        }
    }
}
