package ManagementAdmin;

import ManagementStu.StuBean;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class CartesianJoin extends JFrame implements ActionListener {
    private JButton JBSubmit = new JButton("ʵ�ֵѿ�������");
    private JButton JBCancel = new JButton("ȡ��");
    private JTextArea JT= new JTextArea();

    public CartesianJoin(){
        this.setTitle("Student^Department�ѿ�������");
        getContentPane().setLayout(null);
        JBSubmit.setBounds(10,107,200,20);
        getContentPane().add(JBSubmit);
        JBSubmit.addActionListener(this);
        JBCancel.setBounds(10,150,60,20);
        getContentPane().add(JBCancel);
        JBCancel.addActionListener(this);
        this.setBounds(10,10,1000,1400);
        this.setLocationRelativeTo(null);//��������Ļ�м���ʾ
        this.setVisible(true);
        JT.setBounds(220,1,800,1320);
        JT.setLineWrap(true);//�Զ�����
        getContentPane().add(JT);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==JBCancel) {
            dispose();
        }
        if (e.getSource()==JBSubmit) {
            AdminDAO dao = new AdminDAO();
            ArrayList list = dao.searchByCartesian();
            if (list.size() == 0) {
                JOptionPane.showMessageDialog(this, "û�����ѧ������Ϣ", "alert",
                        JOptionPane.INFORMATION_MESSAGE);
            }
            else {
                JT.setText("   Sno   |Sname|Ssex|Scard|Clno|   Stime   |Dno|    Dname    | Dhead |      Dphon"+"\n"+list.toString());
            }
        }
    }
}
