package ManagementAdmin;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class RightJoin extends JFrame implements ActionListener {
    private JButton JBSubmit = new JButton("ʵ��������");
    private JButton JBCancel = new JButton("ȡ��");
    private JTextArea JT= new JTextArea();

    public RightJoin(){
        this.setTitle("Student^SC ������");
        getContentPane().setLayout(null);
        JBSubmit.setBounds(10,107,200,20);
        getContentPane().add(JBSubmit);
        JBSubmit.addActionListener(this);
        JBCancel.setBounds(10,150,60,20);
        getContentPane().add(JBCancel);
        JBCancel.addActionListener(this);
        this.setBounds(10,10,500,300);
        this.setLocationRelativeTo(null);//��������Ļ�м���ʾ
        this.setVisible(true);
        JT.setBounds(220,1,200,200);
        JT.setLineWrap(true);//�Զ�����
        getContentPane().add(JT);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==JBCancel) {
            dispose();
        }
        if (e.getSource()==JBSubmit) {
            AdminDAO dao = new AdminDAO();
            ArrayList list = dao.searchByRight();
            if (list.size() == 0) {
                JOptionPane.showMessageDialog(this, "û�����ѧ������Ϣ", "alert",
                        JOptionPane.INFORMATION_MESSAGE);
            }
            else {
                JT.setText(list.toString());
            }
        }
    }
}
