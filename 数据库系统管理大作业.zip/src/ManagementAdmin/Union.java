package ManagementAdmin;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import ManagementCon.ConAdmDB;
import ManagementStu.StuBean;

import java.awt.BorderLayout;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Union extends JFrame implements ActionListener{
    private JLabel JLClno = new JLabel("Ҫ��ѯ�İ༶��");
    private JTextField JTClno = new JTextField();
    private JLabel JLSFname = new JLabel("Ҫ���ղ�ѯ��");
    private JTextField JTSFname = new JTextField();
    private JButton JBSubmit = new JButton("ȷ��");
    private JButton JBCancel = new JButton("ȡ��");
    private JTextArea JT= new JTextArea();

    public Union() {
        this.setTitle("����Ų�ѯ+���ղ�ѯ");
        getContentPane().setLayout(null);

        JLClno.setBounds(10,28,90,20);
        getContentPane().add(JLClno);
        JLSFname.setBounds(10,148,90,20);
        getContentPane().add(JLSFname);
        JTClno.setBounds(10,60,123,20);
        getContentPane().add(JTClno);
        JTSFname.setBounds(10,170,123,20);
        getContentPane().add(JTSFname);
        JBSubmit.setBounds(10,257,60,20);
        getContentPane().add(JBSubmit);
        JBSubmit.addActionListener(this);
        JBCancel.setBounds(90,257,60,20);
        getContentPane().add(JBCancel);
        JBCancel.addActionListener(this);
        this.setBounds(10,10,736,400);
        this.setLocationRelativeTo(null);//��������Ļ�м���ʾ
        this.setVisible(true);
        JT.setBounds(220,10,450,320);
        JT.setLineWrap(true);//�Զ�����
        getContentPane().add(JT);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==JBCancel) {
            dispose();
        }
        if (e.getSource()==JBSubmit) {
            AdminDAO dao = new AdminDAO();
            StuBean bean = new StuBean();
            bean.setClno(JTClno.getText());
            bean.setSFirstName(JTSFname.getText());
            ArrayList list = dao.searchStuBySno_firstName(bean);
            if (list.size() == 0) {
                JOptionPane.showMessageDialog(this, "û�����ѧ������Ϣ", "alert",
                        JOptionPane.INFORMATION_MESSAGE);
            }
            else {
                JT.setText("    ѧ��    | ���� |�Ա�|����|�༶|��ѧʱ��"+"\n"+list.toString());
            }
        }
    }
}
