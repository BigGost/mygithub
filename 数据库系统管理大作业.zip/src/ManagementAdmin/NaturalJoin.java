package ManagementAdmin;

import ManagementCon.ClaBean;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class NaturalJoin extends JFrame implements ActionListener {
    private JLabel JLClname = new JLabel("Ҫ��ѯ�İ༶:��������");
    private JTextField JTClname = new JTextField();
    private JButton JBSubmit = new JButton("ȷ��");
    private JButton JBCancel = new JButton("ȡ��");
    private JTextArea JT= new JTextArea();

    public NaturalJoin(){
        this.setTitle("������ĳ���ѧ��������ѧ��");
        getContentPane().setLayout(null);
        JLClname.setBounds(10,148,140,20);
        getContentPane().add(JLClname);
        JTClname.setBounds(10,170,123,20);
        getContentPane().add(JTClname);
        JBSubmit.setBounds(10,257,60,20);
        getContentPane().add(JBSubmit);
        JBSubmit.addActionListener(this);
        JBCancel.setBounds(90,257,60,20);
        getContentPane().add(JBCancel);
        JBCancel.addActionListener(this);
        this.setBounds(10,10,736,400);
        this.setLocationRelativeTo(null);//��������Ļ�м���ʾ
        this.setVisible(true);
        JT.setBounds(220,10,450,320);
        JT.setLineWrap(true);//�Զ�����
        getContentPane().add(JT);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==JBCancel) {
            dispose();
        }
        if (e.getSource()==JBSubmit) {
            AdminDAO dao = new AdminDAO();
            ClaBean bean = new ClaBean();
            bean.setClname(JTClname.getText());
            ArrayList list = dao.searchStuByClname(bean);
            if (list.size() == 0) {
                JOptionPane.showMessageDialog(this, "û�����ѧ������Ϣ", "alert",
                        JOptionPane.INFORMATION_MESSAGE);
            }
            else {
                JT.setText("    ѧ��    | ���� "+"\n"+list.toString());
            }
        }
    }
}
