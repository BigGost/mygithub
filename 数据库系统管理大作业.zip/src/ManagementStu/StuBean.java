package ManagementStu;

public class StuBean {
    private String Sno;
    private String Sname;
    private String SFirstName;
    private String Ssex;
    private String Scard;
    private String Clno;
    private String Clname;
    private String Cname;
    private String Mno;
    private String Stime;
    private String password;
    
    public String getSno() {
        return Sno;
    }

    public String getSname() {
        return Sname;
    }

    public String getSFirstName() {return SFirstName;}

    public String getSsex() {
        return Ssex;
    }

    public String getScard() {
        return Scard;
    }

    public String getClno() {
        return Clno;
    }
    
    public String getClname() {
        return Clname;
    }
    
    public String getCname() {
        return Cname;
    }

    public String getMno() {
        return Mno;
    }
    public String getStime() {
        return Stime;
    }
    public String getpassword() {
        return password;
    }
 
    public void setSno(String Sno) {
        this.Sno = Sno;
    }
    public void setSname(String Sname) {
        this.Sname = Sname;
    }
    public void setSFirstName(String SFirstName) {this.SFirstName = SFirstName;}
    public void setClno(String Clno){this.Clno = Clno;}
    public void setClname(String Clname) {
        this.Clname = Clname;
    }
    public void setCname(String Cname) {
        this.Cname = Cname;
    }
    public void setpassword(String password) {
        this.password = password;
    }
    public void setStime(String Stime) {
        this.Stime = Stime;
    }


}
