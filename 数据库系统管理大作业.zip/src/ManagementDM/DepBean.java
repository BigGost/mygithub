package ManagementDM;

public class DepBean {
    private String Dno;
    private String Dname;
    private String Dhead;
    private String Dphone;
    
    public String getDno() {
        return Dno;
    }

    public String getDname() {
        return Dname;
    }
    
    public String getDhead() {
        return Dhead;
    }

    public String getDphone() {
        return Dphone;
    }
 
    public void setDno(String Dno) {
        this.Dno = Dno;
    }
    public void setDname(String Dname) {
        this.Dname = Dname;
    }
    public void setDhead(String Dhead) {
        this.Dhead = Dhead;
    }
    public void setDphone(String Dphone) {
        this.Dphone = Dphone;
    }


}
