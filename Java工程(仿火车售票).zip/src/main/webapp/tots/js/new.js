$(".name").click(function(){
    $('.x').removeClass('x')
    $(this).addClass('x')
})

